package pract07.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import fundamentos_test.test.infraestructura.FundamentosTest;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;

import java.util.HashSet;
import pract07.gui.GUIRestaurante;

/**
 * Test de la clase Restaurante (examen marzo 22-23, informatica).
 * Usa "Fundamentos test".
 * 
 * @author  Metodos de Programacion (UC)
 * @version abr-22
 */
class RestauranteTest {
	// datos globales para los tests
	private static final int NUM_MESAS = 15;

	// opciones del menu
	private static final int BUSCA_MESA_LIBRE = GUIRestaurante.BUSCA_MESA_LIBRE;
	private static final int ANOTA_CONSUMICION = GUIRestaurante.ANOTA_CONSUMICION;
	private static final int COBRA_MESA = GUIRestaurante.COBRA_MESA;
	private static final int NUM_MESAS_CON_CONSUMICION = GUIRestaurante.NUM_MESAS_CON_CONSUMICION;
	private static final String[] OPTION_NAMES = {"BUSCA_MESA_LIBRE",
		"ANOTA_CONSUMICION", "COBRA_MESA", "NUM_MESAS_CON_CONSUMICION"};

	// Mensajes GUI
	private static final String[][] msjsGUI =
		{
				{"Numero de mesa", "No quedan mesas"}, // BUSCA_MESA_LIBRE
				{"Consumicion anhadida", "incorrecto"}, // ANOTA_CONSUMICION
				{"Mesa cobrada", "mesa incorrecto"}, // COBRA_MESA
				{"Mesas con"} // NUM_MESAS_CON_CONSUMICION			
		};
	
	@Test
	void buscaMesaTest() {
		System.out.println("buscaMesaTest");
		HashSet<Integer> numMesas = new HashSet<>();
		
		// comprueba que puede pedir NUM_MESAS
		for (int i = 0; i < NUM_MESAS; i++) {
			final int mesaLibre = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
			assertTrue(!numMesas.contains(mesaLibre));
			numMesas.add(mesaLibre);
		}
		
		// comprueba que no puede pedir ninguna mas
		FundamentosTest.interaccionGUI(BUSCA_MESA_LIBRE, "No quedan mesas");
	}

	@Test
	void buscaMesaCobraTest() {
		System.out.println("buscaMesaCobraTest");
		HashSet<Integer> numMesas = new HashSet<>();
		
		// comprueba que puede pedir NUM_MESAS
		for (int i = 0; i < NUM_MESAS; i++) {
			final int mesaLibre = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
			assertTrue(!numMesas.contains(mesaLibre));
			numMesas.add(mesaLibre);
		}
		
		// cobra una de las mesas
		FundamentosTest.interaccionGuiOK(COBRA_MESA, NUM_MESAS / 2);
		numMesas.remove(NUM_MESAS / 2);
		
		// comprueba que retorna la cobrada
		final int mesaLibre = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		assertEquals(NUM_MESAS / 2, mesaLibre);
		numMesas.add(mesaLibre);
	}

	@Test
	void anotaConsumicionErrorNumTest() {
		System.out.println("anotaConsumicionErrorNumTest");
		
		// comprueba que es un error un numero no valido
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				-1, "XX", 2.0);
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				NUM_MESAS, "XX", 2.0);
	}

	@Test
	void anotaConsumicionMesaLibreTest() {
		System.out.println("anotaConsumicionMesaLibreTest");
		
		// comprueba que es un error una mesa libre
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				0, "XX", 2.0);
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				(NUM_MESAS - 1), "XX", 2.0);
		
		// comprueba que va bien si la mesa esta ocupada
		final int mesaLibre = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION, mesaLibre, "XX", 2.0);		
	}

	@Test
	void cobraMesaErrorNumTest() {
		System.out.println("cobraMesaErrorNumTest");
		
		// comprueba que es un error un numero no valido
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto", -1);
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto", NUM_MESAS);

	}
	
	@Test
	void cobraMesaMesaLibreTest() {
		System.out.println("cobraMesaMesaLibreTest");
		
		// comprueba que es un error una mesa libre
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto", 0);
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto", (NUM_MESAS - 1));
		
		// comprueba que va bien si la mesa esta ocupada
		final int mesaLibre = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		FundamentosTest.interaccionGuiOK(COBRA_MESA, mesaLibre);		
	}
	
	@Test
	void cobraSimpleTest() {
		System.out.println("cobraSimpleTest");
		final double precio = 4.0;
		
		// ocupa 2 mesas
		final int mesa0 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		final int mesa1 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		
		// hace una consumicion en una de ellas
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION, mesa1, "XX", precio);
		
		// comprueba que los pagos son correctos
		final double cuenta0 = FundamentosTest.leeDoubleGuiOK(COBRA_MESA, mesa0);
		assertEquals(0, cuenta0, 0.001);
		final double cuenta1 = FundamentosTest.leeDoubleGuiOK(COBRA_MESA, mesa1);
		assertEquals(precio, cuenta1, 0.001);
	}

	@Test
	void cobraVariasConsumicionesTest() {
		System.out.println("cobraVariasConsumicionesTest");
		final double precio1 = 4.0;
		final double precio2 = 2.0;
		final double precio3 = 1.0;
		
		// ocupa 2 mesas
		final int mesa0 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		final int mesa1 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		
		// hace consumiciones en una de ellas
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION, mesa0, "XX", precio1);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION, mesa1, "XX", precio2);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION, mesa1, "XX", precio3);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION, mesa0, "XX", precio1);
		
		// comprueba que los pagos son correctos
		final double cuenta0 = FundamentosTest.leeDoubleGuiOK(COBRA_MESA, mesa0);
		assertEquals(precio1 + precio1, cuenta0, 0.001);
		final double cuenta1 = FundamentosTest.leeDoubleGuiOK(COBRA_MESA, mesa1);
		assertEquals(precio2 + precio3, cuenta1, 0.001);
	}

	@Test
	void cobraMesaLiberaTest() {
		System.out.println("cobraMesaLiberaTest");
		
		// comprueba que es un error una mesa libre
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto", 0);
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto",
				(NUM_MESAS - 1));
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				0, "XX", 2.0);
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				(NUM_MESAS - 1), "XX", 2.0);
		
		// comprueba que va bien si la mesa esta ocupada
		final int mesaLibre = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				mesaLibre, "XX", 2.0);
		FundamentosTest.interaccionGuiOK(COBRA_MESA, mesaLibre);		
		
		// comprueba que vuelve a ser un error
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto", mesaLibre);
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto", 0);
		FundamentosTest.interaccionGUI(COBRA_MESA, "mesa incorrecto",
				(NUM_MESAS - 1));
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				mesaLibre, "XX", 2.0);
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				0, "XX", 2.0);
		FundamentosTest.interaccionGUI(ANOTA_CONSUMICION, "incorrecto",
				(NUM_MESAS - 1), "XX", 2.0);	
	}

	@Test
	void cobraMesaReocupadaTest() {
		System.out.println("cobraMesaReocupadaTest");
		final double precio1 = 1.0;
		final double precio2 = 2.0;
		final double precio3 = 4.0;
		final int numMesa = 3;
		
		// ocupa todas las mesas
		for (int i = 0; i < NUM_MESAS; i++) {
			FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		}
		
		// realiza consumiciones en una de ellas y la cobra
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa, "XX", precio1);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa, "XX", precio2);
		FundamentosTest.leeDoubleGuiOK(COBRA_MESA, numMesa);
		
		// vuelve a ocuparla
		final int numMesa2 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		assertEquals(numMesa, numMesa2);
		
		// vuelve a realizar consumiciones
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa, "XX", precio2);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa, "XX", precio3);
		
		// comprueba que el precio solo incluye las de la ultima vez
		final double cuenta = FundamentosTest.leeDoubleGuiOK(COBRA_MESA, numMesa);
		assertEquals(precio2 + precio3, cuenta, 0.001);
	}

	@Test
	void mesasConConsumicionSencilloTest() {
		System.out.println("mesasConConsumicionSencilloTest");
		final String desc = "XYZ";
		int numMesas;
		
		// comprueba que al principio ninguna mesa tiene la consumicion
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc);
		assertEquals(0, numMesas);
		
		// realiza una consumicion en una mesa
		final int numMesa = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION, numMesa, desc, 4.5);
		
		// comprueba que encuentra la descripcion en una mesa
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc);
		assertEquals(1, numMesas);
		
		// pero no encuentra otra
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, "ABC");
		assertEquals(0, numMesas);
	}
	
	@Test
	void mesasConConsumicionReocupaTest() {
		System.out.println("mesasConConsumicionReocupaTest");
		final String desc = "XYZ";
		int numMesas;
		
		// comprueba que al principio ninguna mesa tiene la consumicion
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc);
		assertEquals(0, numMesas);
		
		// realiza una consumicion en una mesa
		final int numMesa = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION, numMesa, desc, 4.5);
		
		// comprueba que encuentra la descripcion en una mesa
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc);
		assertEquals(1, numMesas);
		
		// libera la mesa
		FundamentosTest.leeDoubleGuiOK(COBRA_MESA, numMesa);
		
		// comprueba que la descripcion no se encuentra en ninguna mesa
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc);
		assertEquals(0, numMesas);
	}

	@Test
	void mesasConConsumicionTest() {
		System.out.println("mesasConConsumicionTest");
		final String desc1 = "XYZ";
		final String desc2 = "ABC";
		final String desc3 = "UVW";
		int numMesas;
		
		// ocupa 3 mesas
		final int numMesa1 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		final int numMesa2 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		final int numMesa3 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		
		// comprueba que las descripciones no estan
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc1);
		assertEquals(0, numMesas);
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc2);
		assertEquals(0, numMesas);
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc3);
		assertEquals(0, numMesas);
		
		// realiza algunas consumiciones
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa1, desc1, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa1, desc2, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa1, desc3, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa2, desc1, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa2, desc2, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa3, desc1, 4.5);
		
		// comprueba que encuentra el numero correcto
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc1);
		assertEquals(3, numMesas);
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc2);
		assertEquals(2, numMesas);
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc3);
		assertEquals(1, numMesas);
	}

	@Test
	void mesasConConsumicionRepetidaTest() {
		System.out.println("mesasConConsumicionRepetidaTest");
		final String desc1 = "XYZ";
		final String desc2 = "ABC";
		final String desc3 = "UVW";
		int numMesas;
		
		// ocupa 3 mesas
		final int numMesa1 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		final int numMesa2 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		final int numMesa3 = FundamentosTest.leeIntGuiOK(BUSCA_MESA_LIBRE);
		
		// realiza algunas consumiciones
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa1, desc1, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa1, desc1, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa1, desc2, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa1, desc3, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa2, desc1, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa2, desc2, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa2, desc2, 4.5);
		FundamentosTest.interaccionGuiOK(ANOTA_CONSUMICION,
				numMesa3, desc1, 4.5);
		
		// comprueba que encuentra el numero correcto
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc1);
		assertEquals(3, numMesas);
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc2);
		assertEquals(2, numMesas);
		numMesas = FundamentosTest.leeIntGuiOK(NUM_MESAS_CON_CONSUMICION, desc3);
		assertEquals(1, numMesas);
	}

	// metodos para la infraestructura de test


	@BeforeAll
	public static void preparaModoTest() {
		FundamentosTest.lanzaModoTest(OPTION_NAMES, msjsGUI, false);
	}

	@AfterAll
	public static void finalizaModoTest() {
		FundamentosTest.finalizaModoTest();
	}

	/**
	 * Se ejecuta antes de cada test.
	 */
	@BeforeEach
	public void lanzaGUI() {
		FundamentosTest.lanzaGUI(GUIRestaurante.class);
	}

	/**
	 * Se ejecuta despues de cada test.
	 * @throws InterruptedException error en thread main.
	 */
	@AfterEach
	public void finalizaGUI() throws InterruptedException {
		FundamentosTest.finalizaGUI(GUIRestaurante.FIN_APLICACION);
	}

}
