package pract07.modelo;

public class Restaurante {
	
	private static final int NUM_MESAS = 15;
	private Mesa[] mesas;
	
	public Restaurante() {
		mesas = new Mesa[NUM_MESAS];
		
		for(int i = 0; i < NUM_MESAS; i++) {
			mesas[i] = new Mesa(i);
		}
		
	}
	
	public int buscaMesaLibre() {
		for(int i = 0; i < NUM_MESAS; i++) {
			if(mesas[i].isLibre()) {
				mesas[i].ocuparMesa();
				return i;
			}
		}
		return -1;
	}
	
	public boolean anotarConsumicion(int idMesa, String descripcion, double precio) {
		if(idMesa < 0 || idMesa >= NUM_MESAS) {
			return false;
		}
		Consumicion nuevaConsumicion = new Consumicion(descripcion, precio);
		return mesas[idMesa].agregarConsumicion(nuevaConsumicion);
	}
	
	public double cobrarMesa(int idMesa) {
		if(idMesa < 0 || idMesa >= NUM_MESAS) {
			return -1.0;
		}
		return mesas[idMesa].cobrarMesa();
	}
	
	public int numMesasConConsumicion(String descripcion) {
		int numMesas = 0;
		for(Mesa mesa : mesas) {
			if(mesa.hasConsumicion(descripcion)) {
				numMesas++;
			}
		}
		return numMesas;
	}
	
}
