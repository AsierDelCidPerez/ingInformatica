package pract07.modelo;

import java.util.ArrayList;

public class Mesa {
	private boolean estaLibre;
	private double totalGasto;
	private int id;
	private ArrayList<Consumicion> consumiciones;
	
	public Mesa(int id) {
		this.id = id;
		estaLibre = true;
		consumiciones = new ArrayList<Consumicion>();
		totalGasto = 0;
	}
	
	public boolean hasConsumicion(String descripcion) {
		for(Consumicion consumicion : consumiciones) {
			if(consumicion.descripcion().equals(descripcion)) {
				return true;
			}
		}
		return false;
	}
	
	private void liberarMesa() {
		totalGasto = 0;
		consumiciones = new ArrayList<Consumicion>();
		estaLibre = true;
	}
	
	public double cobrarMesa() {
		if(estaLibre) {
			return -1.0;
		}
		double totalAPagar = totalGasto;
		liberarMesa();
		return totalAPagar;
	}
	
	public boolean agregarConsumicion(Consumicion consumicion) {
		if(estaLibre) {
			return false;
		}
		
		consumiciones.add(consumicion);
		totalGasto += consumicion.precio();
		return true;
		
	}
	
	public void ocuparMesa() {
		estaLibre = false;
	}
	
	public boolean isLibre() {
		return estaLibre;
	}
	
}
