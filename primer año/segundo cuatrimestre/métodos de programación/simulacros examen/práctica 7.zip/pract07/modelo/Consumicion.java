package pract07.modelo;

/**
 * Consumicion realizada en la mesa de un restaurante
 * @author Metodos de Programacion (UC)
 * @version mar-23
 */
public class Consumicion {
	private final String descripcion;
	private final double precio;
	
	/**
	 * Construye una consumicion.
	 * @param descripcion descripcion de la consumicion.
	 * @param precio precio de la consumicion.
	 */
	public Consumicion(String descripcion, double precio) {
		this.descripcion = descripcion;
		this.precio = precio;
	}
	
	/**
	 * Retorna la descripcion de la consumicion.
	 * @return la descripcion de la consumicion.
	 */
	public String descripcion() {
		return descripcion;
	}
	
	/**
	 * Retorna el precio de la consumicion.
	 * @return el precio de la consumicion.
	 */
	public double precio() {
		return precio;
	}
}
