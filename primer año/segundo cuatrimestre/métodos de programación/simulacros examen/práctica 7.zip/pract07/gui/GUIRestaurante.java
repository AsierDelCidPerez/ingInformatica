package pract07.gui;

import fundamentos_test.*;
import pract07.modelo.Restaurante;

/**
 * Interfaz Grafica de Usuario (GUI) de la aplicacion para la gestion de las
 * consumiciones y mesas de un restaurante.
 * 
 * @author  Metodos de Programacion (UC) y <TODO: nombre alumno>
 * @version mar-23
 */
public class GUIRestaurante {
	// opciones del menu
	public static final int BUSCA_MESA_LIBRE = 0;
	public static final int ANOTA_CONSUMICION = 1;
	public static final int COBRA_MESA = 2;
	public static final int NUM_MESAS_CON_CONSUMICION = 3;
	public static final int FIN_APLICACION = 5;

	/**
	 * Programa principal basado en menu.
	 * @param args argumentos del programa principal (no usados)
	 * @throws AssertionError si se ha producido un error no esperado.
	 */
	public static void main(String[] args) {

		// variables auxiliares
		Lectura lect;
		int numMesa;
		String descrConsumicion;

		// crea el restaurante
		Restaurante restaurante = new Restaurante();

		// crea la ventana de menu
		Menu menu = FundamentosFactory.getMenu("Comisiones tienda");
		menu.insertaOpcion("Busca mesa libre", BUSCA_MESA_LIBRE);
		menu.insertaOpcion("Anota consumicion", ANOTA_CONSUMICION);
		menu.insertaOpcion("Cobra mesa", COBRA_MESA);
		menu.insertaOpcion("Mesas con consumicion", NUM_MESAS_CON_CONSUMICION);

		int opcion;

		// lazo de espera de comandos del usuario
		while (true) {
			opcion = menu.leeOpcion();
			if (opcion == FIN_APLICACION) {
				break;
			}

			// realiza las acciones dependiendo de la opcion elegida
			switch (opcion) {
			case BUSCA_MESA_LIBRE:				
				// busca una mesa libre
				int mesa = restaurante.buscaMesaLibre();
				if (mesa == -1) {
					mensaje("ERROR", "No quedan mesas libres");
				} else {
					mensaje("Mesa libre",
							"Numero de mesa libre " + mesa);
				}
				break;

			case ANOTA_CONSUMICION:
				lect = FundamentosFactory.getLectura("Anota consumicion");
				lect.creaEntrada("Numero mesa", 0);
				lect.creaEntrada("Descripcion consumicion", "Filete");
				lect.creaEntrada("Precio consumicion", 10.0);
				lect.esperaYCierra();
				numMesa = lect.leeInt("Numero mesa");
				descrConsumicion = lect.leeString("Descripcion consumicion");
				double precio = lect.leeDouble("Precio consumicion");

				// anota la consumicion a la mesa
				boolean exito = restaurante.anotarConsumicion(numMesa, descrConsumicion, precio);
				
				if (!exito) {
					mensaje("ERROR", "Numero de mesa incorrecto");
				} else {
					mensaje("Consumicion anhadida",
							"Consumicion anhadida a la mesa " + numMesa);
				}
				break;

			case COBRA_MESA:
				lect = FundamentosFactory.getLectura("Cobra mesa");
				lect.creaEntrada("Numero mesa", 0);
				lect.esperaYCierra();
				numMesa = lect.leeInt("Numero mesa");

				// cobra mesa
				double total = restaurante.cobrarMesa(numMesa);
				if (total == -1.0) { // TODO
					mensaje("ERROR", "Numero de mesa incorrecto");
				} else {
					mensaje("Mesa cobrada",
							"Mesa cobrada:" + numMesa +
							" Total cuenta: " + total);
				}
				break;

			case NUM_MESAS_CON_CONSUMICION:
				lect = FundamentosFactory.getLectura("Mesas con consumicion");
				lect.creaEntrada("Descripcion consumicion", "Filete");
				lect.esperaYCierra();
				descrConsumicion = lect.leeString("Descripcion consumicion");

				// numero de mesas con una consumicion dada
				int num = restaurante.numMesasConConsumicion(descrConsumicion);
				mensaje("Mesas con consumicion",
						"Mesas con " + descrConsumicion + ": " + num);
				break;

			default:
				throw new AssertionError("Opcion no esperada");
			}
		}
	}

	/**
	 * Metodo auxiliar que muestra un ventana de mensaje.
	 * @param titulo titulo de la ventana
	 * @param txt texto contenido en la ventana
	 */
	private static void mensaje(String titulo, String txt) {
		Mensaje msj = FundamentosFactory.getMensaje(titulo);
		msj.escribe(txt);
	}

}
