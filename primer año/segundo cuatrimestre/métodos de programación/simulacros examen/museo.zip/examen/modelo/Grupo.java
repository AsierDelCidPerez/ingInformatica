package examen.modelo;

/**
 * Grupo que realiza una visita guiada a un museo.
 *  
 * @author Metodos de Programacion (UC) y <TODO: nombre alumno>
 * @version mar-2024
 */
public class Grupo {
	private String id;
	private int tamanio;
	private static int ultimoCodigo = 0;
	
	public Grupo(int tamanio) {
		this.tamanio = tamanio;
		++ultimoCodigo;
		id = "GRP" + ultimoCodigo;
	}
	
	public String getId() {
		return id;
	}
	
	public int getTamanio() {
		return tamanio;
	}
	
}
