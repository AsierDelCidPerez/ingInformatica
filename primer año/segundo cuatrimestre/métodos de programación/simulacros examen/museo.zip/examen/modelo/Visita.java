package examen.modelo;

import java.util.ArrayList;

public class Visita {
	private ArrayList<Grupo> grupos;
	private int id, tamanio;
	
	public Visita(int id) {
		this.id = id;
		tamanio = 0;
		grupos = new ArrayList<Grupo>();
	}
	
	public int getCapacidad() {
		return tamanio;
	}
	
	private int buscaGrupo(String id) {
		for(int i=0;i<grupos.size();i++) {
			if(grupos.get(i).getId().equals(id)) return i;
		}
		return -1;
	}
	
	public boolean anularReserva (String id) {
		int grupoEncontrado = buscaGrupo(id);
		if(grupoEncontrado == -1) {
			// No se ha encontrado el grupo
			return false;
		}
		// Removemos el grupo guardado por referencia.
		tamanio -= grupos.get(grupoEncontrado).getTamanio();
		grupos.remove(grupoEncontrado);
		return true;
	}
	
	public int reservasConCapacidadAlMenos(int minCapacidad) {
		ArrayList<Grupo> reservasConCapacidad = new ArrayList<Grupo>();
		for(Grupo g : grupos) {
			if(g.getTamanio() >= minCapacidad) reservasConCapacidad.add(g);
		}
		return reservasConCapacidad.size();
	}
	
	public boolean addReserva(Grupo reserva) {
		if(Museo.CAPACIDAD_POR_VISITA >= tamanio + reserva.getTamanio()) {
			grupos.add(reserva);
			tamanio += reserva.getTamanio();
			return true;
		}
		return false;
	}
	
	public int getId() {
		return id;
	}
	
	public int numEspaciosLibres() {
		return Museo.CAPACIDAD_POR_VISITA - tamanio;
	}
	
}
