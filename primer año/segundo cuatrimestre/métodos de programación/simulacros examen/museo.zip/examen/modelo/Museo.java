package examen.modelo;


public class Museo {
	// Using default attribute modifier for package accesing.
	static final int CAPACIDAD_POR_VISITA = 15;
	private static final int NUM_VISITAS_GUIADAS = 4;
	private Visita[] visitas;
	
	public Museo() {
		visitas = new Visita[NUM_VISITAS_GUIADAS];
		for(int idVis=0;idVis<NUM_VISITAS_GUIADAS;idVis++) {
			visitas[idVis] = new Visita(idVis);
		}
	}
	
	public boolean realizarReserva(int idVis, int tam) {
		if(idVis < 0 || idVis >= NUM_VISITAS_GUIADAS) {
			return false;
		}
		Grupo nuevoGrupo = new Grupo(tam);
		return visitas[idVis].addReserva(nuevoGrupo);
	}
	
	public boolean anularReserva(int idVis, String idGr) {
		if(idVis < 0 || idVis >= NUM_VISITAS_GUIADAS) {
			return false;
		}
		return visitas[idVis].anularReserva(idGr);
	}
	
	public int numGruposTamVisita(int idVis, int minTam) {
		if(idVis < 0 || idVis >= NUM_VISITAS_GUIADAS) {
			return -1;
		}
		
		return visitas[idVis].reservasConCapacidadAlMenos(minTam);
		
	}
	
	public Visita visitaConCapacidad(int tamanio) {
		// Devuelve la primera visita cuya capacidad libre sea mayor o igual a tamanio
		for(Visita vis : visitas) {
			if(vis.numEspaciosLibres() >= tamanio) {
				return vis;
			}
		}
		return null;
	}
	
}
