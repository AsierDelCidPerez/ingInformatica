package examen.modelo;

public class Empresa {
	private static final int NUM_ALMACENES = 4;
	private static final String[] DIRECCIONES = {
			"Calle A", "Calle B", "Calle C", "Calle D"
	};
	private Almacen[] almacenes;
	
	public Empresa() {
		almacenes = new Almacen[NUM_ALMACENES];
		for(int i=0;i<NUM_ALMACENES;i++) {
			almacenes[i] = new Almacen(DIRECCIONES[i], i);
		}
	}

	private boolean isAlmacenValido(int almacen) {
		if(almacen < 0 || almacen >= NUM_ALMACENES) {
			return false;
		}
		return true;
	}
	
	public int consultarUnidades(String codigoProducto, int almacenCodigo) {
		if(!isAlmacenValido(almacenCodigo)) {
			return -1;
		}
		
		return almacenes[almacenCodigo].consultarUnidades(codigoProducto);
		
	}
	
	public boolean almacenarProducto(String productoCodigo, int unidades, int almacenCodigo) {
		if(!isAlmacenValido(almacenCodigo)) {
			return false;
		}
		almacenes[almacenCodigo].addProducto(productoCodigo, unidades);
		return true;
	}
	
	public boolean mueveProductos(int almacenEmisor, int almacenReceptor, String pCodigo) {
		if(!isAlmacenValido(almacenReceptor) || !isAlmacenValido(almacenEmisor)) {
			return false;
		}
		
		int unidadesTotales = almacenes[almacenEmisor].consultarUnidades(pCodigo);
		if(unidadesTotales == -1) {
			return false;
		}
		boolean valido = almacenes[almacenEmisor].retirarUnidades(pCodigo, unidadesTotales);
		if(valido) {
			almacenes[almacenReceptor].addProducto(pCodigo, unidadesTotales);
			return true;
		}
		return false;
	}
	
	public Almacen eliminaUnidadesDeProducto(String pCodigo, int unidades) {
		for(Almacen almacen : almacenes) {
			if(almacen.consultarUnidades(pCodigo) >= unidades) {
				boolean valido = almacen.retirarUnidades(pCodigo, unidades);
				if(valido) {
					return almacen;
				}
			}
		}
		return null;
	}
	
}
