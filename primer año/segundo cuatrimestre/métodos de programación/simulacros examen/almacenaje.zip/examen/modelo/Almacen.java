package examen.modelo;

import java.util.ArrayList;

public class Almacen {
	private String direccion;
	private int idAlmacen;
	private ArrayList<Producto> productos;
	
	public Almacen(String direccion, int idAlmacen) {
		this.direccion = direccion;
		productos = new ArrayList<Producto>();
		this.idAlmacen = idAlmacen;
	}
	
	private Producto buscaProducto(String pCodigo) {
		for(Producto producto : productos) {
			if(producto.getCodigo().equals(pCodigo)) {
				return producto;
			}
		}
		return null;
	}
	
	public int getIdAlmacen() {
		return idAlmacen;
	}
	
	public void addProducto(String pCodigo, int unidades) {
		Producto miProducto = buscaProducto(pCodigo);
		if(miProducto == null) {
			productos.add(new Producto(pCodigo, unidades));
		}else {
			miProducto.sumaUnidades(unidades);
		}
	}
	
	public int consultarUnidades(String pCodigo) {
		Producto miProducto = buscaProducto(pCodigo);
		if(miProducto == null) {
			return 0;
		}
		return miProducto.getUnidades();
	}
	
	public boolean retirarUnidades(String pCodigo, int unidades) {
		if(unidades < 0) {
			return false;
		}
		
		Producto miProducto = buscaProducto(pCodigo);
		
		if(miProducto == null) {
			return false;
		}
		
		if(miProducto.getUnidades() >= unidades) {
			return miProducto.retiraUnidades(unidades);
		}
		
		return false;
	}
	
	public String getDireccion() {
		return direccion;
	}
	
}
