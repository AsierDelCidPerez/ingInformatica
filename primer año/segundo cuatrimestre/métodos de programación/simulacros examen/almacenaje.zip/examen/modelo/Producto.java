package examen.modelo;

public class Producto {
	private String codigo;
	private int unidades;
	
	public Producto(String codigo, int unidades) {
		this.codigo = codigo;
		this.unidades = unidades;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public int getUnidades() {
		return unidades;
	}
	
	public boolean sumaUnidades(int unidades) {
		if(unidades < 0) {
			return false;
		}
		this.unidades += unidades;
		return true;
	}
	
	public boolean retiraUnidades(int unidades) {
		if(unidades < 0) {
			return false;
		}
		this.unidades -= unidades;
		return true;
	}
	
}
