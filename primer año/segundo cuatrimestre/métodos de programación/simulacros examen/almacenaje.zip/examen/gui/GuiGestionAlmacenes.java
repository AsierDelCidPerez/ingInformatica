package examen.gui;

import examen.modelo.Almacen;
import examen.modelo.Empresa;
import fundamentos_test.*;

/**
 * Interfaz Grafica de Usuario (GUI) de la aplicacion para la gestion de los
 * productos almacenados en los almacenes de una empresa.
 * 
 * @author  Metodos de Programacion (UC) y <TODO: nombre alumno>
 * @version oct-24
 */
public class GuiGestionAlmacenes {
	// opciones del menu
	public static final int ALMACENA_UNIDADES_PRODUCTO = 0;
	public static final int CONSULTA_UNIDADES_PRODUCTO = 1;
	public static final int MUEVE_PRODUCTO = 2;
	public static final int ELIMINA_UNIDADES_PRODUCTO = 3;
	public static final int FIN_APLICACION = 4;

	/**
	 * Programa principal basado en menu.
	 * @param args argumentos del programa principal (no usados)
	 * @throws AssertionError si se ha producido un error no esperado.
	 */
	public static void main(String[] args) {

		// variables auxiliares
		int numAlmacen;
		int numUnidades;
		String codProducto;
		Lectura lect;
		boolean correcto;

		// crea la empresa de almacenaje
		Empresa empresa = new Empresa();

		// crea la ventana de menu
		Menu menu = FundamentosFactory.getMenu("Gestion almacenes");
		menu.insertaOpcion("Almacena unidades producto", ALMACENA_UNIDADES_PRODUCTO);
		menu.insertaOpcion("Consulta unidades producto", CONSULTA_UNIDADES_PRODUCTO);
		menu.insertaOpcion("Mueve producto", MUEVE_PRODUCTO);
		menu.insertaOpcion("Elimina unidades producto", ELIMINA_UNIDADES_PRODUCTO);
		int opcion;

		// lazo de espera de comandos del usuario
		while (true) {
			opcion = menu.leeOpcion();
			if (opcion == FIN_APLICACION) {
				break;
			}

			// realiza las acciones dependiendo de la opcion elegida
			switch (opcion) {
			case ALMACENA_UNIDADES_PRODUCTO:
				lect = FundamentosFactory.getLectura("Almacena unidades");
				lect.creaEntrada("Numero almacen", 0);
				lect.creaEntrada("Codigo producto", "P1");
				lect.creaEntrada("Numero unidades producto", 10);
				lect.esperaYCierra();
				numAlmacen = lect.leeInt("Numero almacen");
				codProducto = lect.leeString("Codigo producto"); 
				numUnidades = lect.leeInt("Numero unidades producto");

				// almacena las unidades del producto en el almacen indicado
				boolean exito = empresa.almacenarProducto(codProducto, numUnidades, numAlmacen);
				if (!exito) { 
					mensaje("ERROR", "Numero de almacen incorrecto");
				} else {
					mensaje("Producto almacenado",
							"Almacenadas " + numUnidades +
							" unidades de " + codProducto +
							" en el almacen " + numAlmacen);
				}
				break;

			case CONSULTA_UNIDADES_PRODUCTO:
				lect = FundamentosFactory.getLectura("Consulta unidades");
				lect.creaEntrada("Numero almacen", 0);
				lect.creaEntrada("Codigo producto", "P1");
				lect.esperaYCierra();
				numAlmacen = lect.leeInt("Numero almacen");
				codProducto = lect.leeString("Codigo producto");

				// Muestra el numero de unidades del producto en el almacen
				numUnidades = empresa.consultarUnidades(codProducto, numAlmacen);
			
				if (numUnidades == -1) {
					mensaje("ERROR", "Numero de almacen incorrecto");
				} else {
					mensaje("Numero unidades",
							"Unidades de " + codProducto +
							" en almacen " + numAlmacen + ": " + numUnidades);
				}
				break;

			case MUEVE_PRODUCTO:
				lect = FundamentosFactory.getLectura("Mueve producto");
				lect.creaEntrada("Numero almacen origen", 0);
				lect.creaEntrada("Numero almacen destino", 1);
				lect.creaEntrada("Codigo producto", "P1");
				lect.esperaYCierra();
				final int numAlmacenOrig = lect.leeInt("Numero almacen origen");
				final int numAlmacenDest = lect.leeInt("Numero almacen destino");
				codProducto = lect.leeString("Codigo producto");

				// Mueve el producto del almacen origen al almacen destino
				exito = empresa.mueveProductos(numAlmacenOrig, numAlmacenDest, codProducto);
				if (!exito) {
					mensaje("ERROR", "Numero de almacen origen o destino " +
							"incorrecto o el almacen origen no contiene el producto");
				} else {
					mensaje("Movido producto",
							"Producto " + codProducto +
							" movido desde el almacen " + numAlmacenOrig + 
							" al almacen " + numAlmacenDest);
				}
				break;

			case ELIMINA_UNIDADES_PRODUCTO:
				lect = FundamentosFactory.getLectura("Elimina unidades");
				lect.creaEntrada("Codigo producto", "P1");
				lect.creaEntrada("Numero unidades producto", 3);
				lect.esperaYCierra();
				codProducto = lect.leeString("Codigo producto"); 
				numUnidades = lect.leeInt("Numero unidades producto");

				// Elimina de un almacen las unidades indicadas del producto
				Almacen miAlmacen = empresa.eliminaUnidadesDeProducto(codProducto, numUnidades);
				// TODO
				if (miAlmacen == null) {
					mensaje("ERROR", "No existe ningun almacen con " +
							"suficientes unidades del producto.");
				} else {
					mensaje("Unidades eliminadas",
							"Eliminadas " + numUnidades +
							" unidades del producto " +  codProducto +
							" del almacen " + miAlmacen.getIdAlmacen() +
							" (direccion: " + miAlmacen.getDireccion() + ")");
				}
				break;

			default:
				throw new AssertionError("Opcion no esperada");
			}
		}
	}

	/**
	 * Metodo auxiliar que muestra un ventana de mensaje.
	 * @param titulo titulo de la ventana
	 * @param txt texto contenido en la ventana
	 */
	private static void mensaje(String titulo, String txt) {
		Mensaje msj = FundamentosFactory.getMensaje(titulo);
		msj.escribe(txt);
	}

}
