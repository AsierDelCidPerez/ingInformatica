package examen.tests;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;

import fundamentos_test.test.infraestructura.FundamentosTest;

import examen.gui.GuiGestionAlmacenes;
import static examen.gui.GuiGestionAlmacenes.*;

/**
 * Test de la aplicacion para la gestion de los productos almacenados en los
 * almacenes de una empresa.
 * Usa "Fundamentos test".
 * 
 * @author  Metodos de Programacion (UC)
 * @version oct-24
 */
class GestionAlmacenesTest {
	// datos globales para los tests
	final String[] DIRECCIONES = {"Calle A", "Calle B", "Calle C", "Calle D"};
	final int NUM_ALMACENES = 4;

	// opciones del menu
	private static final String[] OPTION_NAMES = {"ALMACENA_UNIDADES_PRODUCTO",
			"CONSULTA_UNIDADES_PRODUCTO", 
			"MUEVE_PRODUCTO", "ELIMINA_UNIDADES_PRODUCTO"};

	// Mensajes GUI
	private static final String[][] msjsGUI =
		{
				{"Almacenadas", "incorrecto"}, // ALMACENA_UNIDADES_PRODUCTO
				{"Unidades", "incorrecto"}, // CONSULTA_UNIDADES_PRODUCTO
				{"movido", "incorrecto"}, // MUEVE_PRODUCTO		
				{"Eliminadas", "No existe"} // ELIMINA_UNIDADES_PRODUCTO	
		};

	@Test
	void almacenaUnidadesErrorNumAlmacenTest() {
		System.out.println("almacenaUnidadesErrorNumAlmacenTest");

		// comprueba que falla con num=-1
		FundamentosTest.interaccionGUI(ALMACENA_UNIDADES_PRODUCTO, "incorrecto",
				-1, "P1", 1);

		// comprueba que falla con num>=NUM_ALMACENES
		FundamentosTest.interaccionGUI(ALMACENA_UNIDADES_PRODUCTO, "incorrecto",
				NUM_ALMACENES, "P1", 1);
		FundamentosTest.interaccionGUI(ALMACENA_UNIDADES_PRODUCTO, "incorrecto",
				NUM_ALMACENES + 3, "P1", 1);

		// comprueba que NO FALLA con numeros validos
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
					num, "P1", 1);
		}
	}

	@Test
	void consultaUnidadesErrorNumAlmacenTest() {
		System.out.println("consultaUnidadesErrorNumAlmacenTest");

		// comprueba que falla con num=-1
		FundamentosTest.interaccionGUI(CONSULTA_UNIDADES_PRODUCTO, "incorrecto",
				-1, "P1");

		// comprueba que falla con num>=NUM_ALMACENES
		FundamentosTest.interaccionGUI(CONSULTA_UNIDADES_PRODUCTO, "incorrecto",
				NUM_ALMACENES, "P1");
		FundamentosTest.interaccionGUI(CONSULTA_UNIDADES_PRODUCTO, "incorrecto",
				NUM_ALMACENES + 4, "P1");

		// comprueba que NO FALLA con numeros validos
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(CONSULTA_UNIDADES_PRODUCTO,
					num, "P1");
		}
	}

	@Test
	void mueveProductoErrorNumAlmacenTest() {
		System.out.println("mueveProductoErrorNumAlmacenTest");

		// almacena productos en almacenes
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
					num, "P" + num, 2);
		}

		// comprueba que falla con num=-1 (en origen y en destino)
		FundamentosTest.interaccionGUI(MUEVE_PRODUCTO, "incorrecto",
				-1, 0, "P0");
		FundamentosTest.interaccionGUI(MUEVE_PRODUCTO, "incorrecto",
				0, -1, "P0");

		// comprueba que falla con num>=NUM_ALMACENES (en origen y en destino)
		FundamentosTest.interaccionGUI(MUEVE_PRODUCTO, "incorrecto",
				NUM_ALMACENES, 0, "P0");
		FundamentosTest.interaccionGUI(MUEVE_PRODUCTO, "incorrecto",
				0, NUM_ALMACENES + 2, "P0");

		// comprueba que NO FALLA con numeros validos
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(MUEVE_PRODUCTO,
					num, (num + 1) % NUM_ALMACENES, "P" + num);
		}
	}

	@Test
	void mueveProductoErrorNoUnidadesTest() {
		System.out.println("mueveProductoErrorNoUnidadesTest");

		// almacena productos en almacenes
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
					num, "P" + num, 2);
		}

		// comprueba que falla con productos que no estan en el almacen origen
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGUI(MUEVE_PRODUCTO, "incorrecto",
					num, (num + 1) % NUM_ALMACENES, "P" + (num + 1));
		}

		// comprueba que NO FALLA con productos que si estan
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(MUEVE_PRODUCTO,
					num, (num + 1) % NUM_ALMACENES, "P" + num);
		}
	}

	@Test
	void eliminaUnidadesErrorNoSuficientesTest() {
		System.out.println("eliminaUnidadesErrorNoSuficientesTest");

		// comprueba que falla con los amacenes vacios
		FundamentosTest.interaccionGUI(ELIMINA_UNIDADES_PRODUCTO, "No existe",
				"P0", 1);

		// almacena productos en almacenes
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
					num, "P" + num, 2);
		}

		// comprueba que falla con mas unidades de las que hay
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGUI(ELIMINA_UNIDADES_PRODUCTO, "No existe",
					"P" + num, 3);
		}

		// comprueba que NO FALLA justo con las unidades de hay
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ELIMINA_UNIDADES_PRODUCTO,
					"P" + num, 2);
		}
	}

	@Test
	void consultaUnidadesSimple1Test() {
		System.out.println("consultaUnidadesSimple1Test");

		// comprueba que los almacenes empiezan con 0 unidades
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P1");
			assertEquals("Num Unidades incorrecto", 0, numUnidades);
		}

		// almacena productos en almacenes
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
					num, "P" + num, 2 * (num + 1));
		}

		// comprueba que el numero de unidades es correcto
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P" + num);
			assertEquals("Num Unidades incorrecto", 2 * (num + 1), numUnidades);
		}

		// comprueba que no se cuentan las unidades de otros almacenes
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P" + (num + 1));
			assertEquals("Num Unidades incorrecto", 0, numUnidades);
		}	
	}

	@Test
	void consultaUnidadesSimple2Test() {
		System.out.println("consultaUnidadesSimple2Test");

		// almacena distinto numero de unidades de un producto en los almacenes
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
					num, "P1", 2 * (num + 1));
		}

		// comprueba que el numero de unidades es correcto
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P1");
			assertEquals("Num Unidades incorrecto", 2 * (num + 1), numUnidades);
		}	
	}

	@Test
	void mueveProductoSimpleTest() {
		System.out.println("mueveProductoSimpleTest");

		// almacena productos en almacenes
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
					num, "P" + num, 3 * (num + 1));
		}

		// mueve el producto de cada almacen al siguiente
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numDest = (num + 1) % NUM_ALMACENES;
			FundamentosTest.interaccionGuiOK(MUEVE_PRODUCTO,
					num, numDest, "P" + num);
		}

		// comprueba que no estan los productos movidos
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P" + num);
			assertEquals("Num Unidades incorrecto", 0, numUnidades);
		}

		// comprueba que estan los productos movidos
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numOrig = (NUM_ALMACENES + num - 1) % NUM_ALMACENES;
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P" + numOrig);
			assertEquals("Num Unidades incorrecto", 3 * (numOrig + 1), 
					numUnidades);
		}
	}

	@Test
	void mueveProductoAnhadeTest() {
		System.out.println("mueveProductoAnhadeTest");

		// almacena producto P0 en los amacenes 1 y 3
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				1, "P0", 2);
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				3, "P0", 5);

		// mueve el producto P0 desde el almacen 3 al 1
		FundamentosTest.interaccionGuiOK(MUEVE_PRODUCTO, 3, 1, "P0");

		// comprueba que todas las unidades de P0 estan en 1
		final int[] unidadesEsperadas = {0, 7, 0, 0};
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P0");
			assertEquals("Num Unidades incorrecto",
					unidadesEsperadas[num], numUnidades);
		}
	}

	@Test
	void eliminaProductoTest() {
		System.out.println("eliminaProductoTest");

		// almacena producto P0 en los amacenes 0, 1 y 3
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				0, "P0", 3);
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				1, "P0", 6);
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				3, "P0", 1);

		// almacena producto P1 en los amacenes 0 y 2
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				0, "P1", 4);
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				2, "P1", 1);

		// elimina 3 unidades del producto P1 (solo puede eliminarlas del almacen 0)
		FundamentosTest.interaccionGuiOK(ELIMINA_UNIDADES_PRODUCTO, "P1", 3);

		// elimina 4 unidades del producto P0 (solo puede eliminarlas del almacen 1)
		FundamentosTest.interaccionGuiOK(ELIMINA_UNIDADES_PRODUCTO, "P0", 4);

		// comprueba las unidades de P0 son las correctas
		final int[] unidadesEsperadas0 = {3, 2, 0, 1};
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P0");
			assertEquals("Num Unidades incorrecto",
					unidadesEsperadas0[num], numUnidades);
		}

		// comprueba las unidades de P1 son las correctas
		final int[] unidadesEsperadas1 = {1, 0, 1, 0};
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P1");
			assertEquals("Num Unidades incorrecto",
					unidadesEsperadas1[num], numUnidades);
		}
	}

	@Test
	void eliminaProductoUnidadesJustasTest() {
		System.out.println("eliminaProductoUnidadesJustasTest");

		// almacena producto P0 en los amacenes 0, 1 y 3
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				0, "P0", 1);
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				1, "P0", 2);
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				3, "P0", 3);

		// almacena producto P1 en el amacen 2
		FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
				2, "P1", 3);

		// elimina 3 unidades del producto P0 (solo puede eliminarlas del almacen 3)
		FundamentosTest.interaccionGuiOK(ELIMINA_UNIDADES_PRODUCTO, "P0", 3);

		// comprueba las unidades de P0 son las correctas
		final int[] unidadesEsperadas0 = {1, 2, 0, 0};
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P0");
			assertEquals("Num Unidades incorrecto",
					unidadesEsperadas0[num], numUnidades);
		}

		// comprueba las unidades de P1 son las correctas
		final int[] unidadesEsperadas1 = {0, 0, 3, 0};
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P1");
			assertEquals("Num Unidades incorrecto",
					unidadesEsperadas1[num], numUnidades);
		}
	}

	@Test
	void eliminaProductoNumDireccionTest() {
		System.out.println("eliminaProductoNumDireccionTest");

		// almacena productos en almacenes
		for (int num = 0; num < NUM_ALMACENES; num++) {
			FundamentosTest.interaccionGuiOK(ALMACENA_UNIDADES_PRODUCTO,
					num, "P" + num, 3 * (num + 1));
		}

		// elimina unidades de cada almacen
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final String respuesta = FundamentosTest.interaccionGuiOK(
					ELIMINA_UNIDADES_PRODUCTO, "P" + num, 1);
			assertTrue(respuesta.contains("almacen " + num),
					"Deberia contener \"almacen " + num + "\"");
			assertTrue(respuesta.contains(DIRECCIONES[num]),
					"Deberia contener \"" + DIRECCIONES[num] + "\"");
		}
		
		// comprueba las unidades son las correctas
		final int[] unidadesEsperadas1 = {2, 5, 8, 11};
		for (int num = 0; num < NUM_ALMACENES; num++) {
			final int numUnidades = FundamentosTest.leeIntGuiOK(
					CONSULTA_UNIDADES_PRODUCTO, num, "P" + num);
			assertEquals("Num Unidades incorrecto",
					unidadesEsperadas1[num], numUnidades);
		}
	}

	/*
	 *  metodos para la infraestructura de test
	 */

	@BeforeAll
	public static void preparaModoTest() {
		FundamentosTest.lanzaModoTest(OPTION_NAMES, msjsGUI, false);
	}

	@AfterAll
	public static void finalizaModoTest() {
		FundamentosTest.finalizaModoTest();
	}

	/**
	 * Se ejecuta antes de cada test.
	 */
	@BeforeEach
	public void lanzaGUI() {
		FundamentosTest.lanzaGUI(GuiGestionAlmacenes.class);
	}

	/**
	 * Se ejecuta despues de cada test.
	 * @throws InterruptedException error en thread main.
	 */
	@AfterEach
	public void finalizaGUI() throws InterruptedException {
		FundamentosTest.finalizaGUI(GuiGestionAlmacenes.FIN_APLICACION);
	}

}
