/**
 * @file
 * @brief Librería para acceder a los datos del concurso Eurovision
 *
 * Author:  Intro_SW
 * Version: 2019
 *
*/


#ifndef EURO_H
#define EURO_H

#include <stdbool.h>

#define NUM_VOTOS                   1117
#define MAX_STRING                    20
#define NUM_PAISES_JURADO             43

typedef enum paises {CYPRUS, PORTUGAL, ICELAND, MALTA, RUSSIA, ARMENIA, GREECE,
                     AUSTRIA, LATVIA, SWEDEN, NETHERLANDS, IRELAND, POLAND, SLOVENIA,
                     BULGARIA, FRANCE, LITHUANIA, SERBIA, CROATIA, ROMANIA, HUNGARY,
                     UKRAINE, UNITED_KINGDOM, MOLDOVA, BELARUS, SWITZERLAND, ALBANIA,
                     SPAIN, AZERBAIJAN, CZECH_REPUBLIC, BELGIUM, NORWAY, FINLAND, DENMARK,
                     ITALY, GEORGIA, ISRAEL, SAN_MARINO, AUSTRALIA, MACEDONIA, GERMANY,
                     MONTENEGRO, ESTONIA} pais_t;

const char paises_string [NUM_PAISES_JURADO][MAX_STRING] =
{   "CYPRUS", "PORTUGAL", "ICELAND", "MALTA", "RUSSIA", "ARMENIA", "GREECE", "AUSTRIA", "LATVIA",
    "SWEDEN", "NETHERLANDS", "IRELAND", "POLAND", "SLOVENIA", "BULGARIA", "FRANCE", "LITHUANIA",
    "SERBIA", "CROATIA", "ROMANIA", "HUNGARY", "UKRAINE", "UNITED_KINGDOM", "MOLDOVA", "BELARUS",
    "SWITZERLAND", "ALBANIA", "SPAIN", "AZERBAIJAN", "CZECH_REPUBLIC", "BELGIUM", "NORWAY", "FINLAND",
    "DENMARK", "ITALY", "GEORGIA", "ISRAEL", "SAN_MARINO", "AUSTRALIA", "MACEDONIA", "GERMANY",
    "MONTENEGRO", "ESTONIA"
};

typedef struct registro_euro {
    pais_t pais_jurado;
    pais_t pais_finalista;
    int puntuacion;
} registro_euro_t;

/**
 * @brief Recupera los datos de las votaciones del concurso Eurovision
 * @param datos Array donde almacenar los datos del concurso
 * @returns true si se han podido recuperar los datos, false en caso de error
 */
bool obten_datos_euro (registro_euro_t datos [NUM_VOTOS]);

#endif // EURO_H
